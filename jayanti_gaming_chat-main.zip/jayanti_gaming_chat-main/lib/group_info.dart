const groupinfo = [
  {
    'name': 'Tips Group',
    'message': 'Hey, how are you doing?',
    'time': '3:53 pm',
    'profilePic':
    'https://upload.wikimedia.org/wikipedia/commons/8/85/Elon_Musk_Royal_Society_%28crop1%29.jpg',
  },
  {
    'name': 'Confirmation Group',
    'message': 'Hello, whats up',
    'time': '2:25 pm',
    'profilePic':
    'https://www.socialketchup.in/wp-content/uploads/2020/05/fi-vill-JOHN-DOE.jpg',
  },
  {
    'name': 'Information Group',
    'message': 'Hello, I want to sleep.',
    'time': '1:03 pm',
    'profilePic':
    'https://media.cntraveler.com/photos/60596b398f4452dac88c59f8/16:9/w_3999,h_2249,c_limit/MtFuji-GettyImages-959111140.jpg',
  },
  {
    'name': 'Payments Group',
    'message': 'Call me, have some work',
    'time': '12:06 pm',
    'profilePic':
    'https://pbs.twimg.com/profile_images/1419974913260232732/Cy_CUavB.jpg',
  },
  {
    'name': 'Feedback Group',
    'message': 'You ate food?',
    'time': '10:00 am',
    'profilePic':
    'https://uploads.dailydot.com/2018/10/olli-the-polite-cat.jpg?auto=compress%2Cformat&ixlib=php-3.3.0',
  },


];