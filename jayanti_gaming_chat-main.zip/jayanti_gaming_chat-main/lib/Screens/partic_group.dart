import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:satta_chat/info.dart';
import 'chatting_screen.dart';

class Participants extends StatefulWidget {
  const Participants({Key? key}) : super(key: key);

  @override
  State<Participants> createState() => _ParticipantsState();
}

class _ParticipantsState extends State<Participants> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(onPressed: () => {
            Navigator.pop(context)
          }, icon: Icon(Icons.arrow_back, color: Colors.amber,)),
          backgroundColor: Colors.black,
          title: Text('',style: TextStyle(
            ),
          ),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 130.0,),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.group_add, color: Colors.amber,
                      ),
                      SizedBox(width: 5,),
                      Text('NEW GROUP' , style: TextStyle(color: Colors.amber , fontSize: 18),),

                    ],
                  ),
                  SizedBox(width: 10,),
                  Text('Add Participants', style: TextStyle(color: Colors.white , fontSize: 18 ),),
                ],
              ),
            )
          ],

        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListTile(
                  title: Text('Rivaan Ranawat', style: TextStyle(fontSize: 22),),
                  leading: Image.network('https://upload.wikimedia.org/wikipedia/commons/8/85/Elon_Musk_Royal_Society_%28crop1%29.jpg',
                  ),

                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListTile(
                  title: Text('John Doe', style: TextStyle(fontSize: 22),),
                  leading: CircleAvatar(

                  )

                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListTile(
                  title: Text('Rivaan Ranawat', style: TextStyle(fontSize: 18),),
                  leading: Image.network('https://upload.wikimedia.org/wikipedia/commons/8/85/Elon_Musk_Royal_Society_%28crop1%29.jpg',
                  ),

                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListTile(
                  title: Text('Rivaan Ranawat', style: TextStyle(fontSize: 18),),
                  leading: Image.network('https://upload.wikimedia.org/wikipedia/commons/8/85/Elon_Musk_Royal_Society_%28crop1%29.jpg',
                  ),

                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListTile(
                  title: Text('Rivaan Ranawat', style: TextStyle(fontSize: 18),),
                  leading: Image.network('https://upload.wikimedia.org/wikipedia/commons/8/85/Elon_Musk_Royal_Society_%28crop1%29.jpg',
                  ),

                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListTile(
                  title: Text('Rivaan Ranawat', style: TextStyle(fontSize: 18),),
                  leading: Image.network('https://upload.wikimedia.org/wikipedia/commons/8/85/Elon_Musk_Royal_Society_%28crop1%29.jpg',
                  ),

                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListTile(
                  title: Text('Rivaan Ranawat', style: TextStyle(fontSize: 18),),
                  leading: Image.network('https://upload.wikimedia.org/wikipedia/commons/8/85/Elon_Musk_Royal_Society_%28crop1%29.jpg',
                  ),

                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListTile(
                  title: Text('Rivaan Ranawat', style: TextStyle(fontSize: 18),),
                  leading: Image.network('https://upload.wikimedia.org/wikipedia/commons/8/85/Elon_Musk_Royal_Society_%28crop1%29.jpg',
                  ),

                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListTile(
                  title: Text('Rivaan Ranawat', style: TextStyle(fontSize: 18),),
                  leading: Image.network('https://upload.wikimedia.org/wikipedia/commons/8/85/Elon_Musk_Royal_Society_%28crop1%29.jpg',
                  ),

                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListTile(
                  title: Text('Rivaan Ranawat', style: TextStyle(fontSize: 18),),
                  leading: Image.network('https://upload.wikimedia.org/wikipedia/commons/8/85/Elon_Musk_Royal_Society_%28crop1%29.jpg',
                  ),

                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListTile(
                  title: Text('Rivaan Ranawat', style: TextStyle(fontSize: 18),),
                  leading: Image.network('https://upload.wikimedia.org/wikipedia/commons/8/85/Elon_Musk_Royal_Society_%28crop1%29.jpg',
                  ),

                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListTile(
                  title: Text('Rivaan Ranawat', style: TextStyle(fontSize: 18),),
                  leading: Image.network('https://upload.wikimedia.org/wikipedia/commons/8/85/Elon_Musk_Royal_Society_%28crop1%29.jpg',
                  ),

                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListTile(
                  title: Text('Rivaan Ranawat', style: TextStyle(fontSize: 18),),
                  leading: Image.network('https://upload.wikimedia.org/wikipedia/commons/8/85/Elon_Musk_Royal_Society_%28crop1%29.jpg',
                  ),

                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListTile(
                  title: Text('Rivaan Ranawat', style: TextStyle(fontSize: 18),),
                  leading: Image.network('https://upload.wikimedia.org/wikipedia/commons/8/85/Elon_Musk_Royal_Society_%28crop1%29.jpg',
                  ),

                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListTile(
                  title: Text('Rivaan Ranawat', style: TextStyle(fontSize: 18),),
                  leading: Image.network('https://upload.wikimedia.org/wikipedia/commons/8/85/Elon_Musk_Royal_Society_%28crop1%29.jpg',
                  ),

                ),
              ),
            ],
          ),
        ),



    )
    );
  }
}
