package com.example.satta_chat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
